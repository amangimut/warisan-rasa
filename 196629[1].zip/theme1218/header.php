<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<title>
	<?php if ( is_tag() ) {
			echo 'Tag Archive for &quot;'.$tag.'&quot; | '; bloginfo( 'name' );
		} elseif ( is_archive() ) {
			wp_title(); echo ' Archive | '; bloginfo( 'name' );
		} elseif ( is_search() ) {
			echo 'Search for &quot;'.wp_specialchars($s).'&quot; | '; bloginfo( 'name' );
		} elseif ( is_home() ) {
			bloginfo( 'name' ); echo ' '; bloginfo( 'description' );
		}  elseif ( is_404() ) {
			echo 'Error 404 Not Found | '; bloginfo( 'name' );
		} else {
			echo wp_title( ' | ', false, right ); bloginfo( 'name' );
		} ?>
	</title>
	<meta name="keywords" content="<?php wp_title(); echo ' , '; bloginfo( 'name' ); echo ' , '; bloginfo( 'description' ); ?>" />
	<meta name="description" content="<?php wp_title(); echo ' | '; bloginfo( 'description' ); ?>" />
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="index" title="<?php bloginfo( 'name' ); ?>" href="<?php echo get_option('home'); ?>/" />
  <?php $favicon = get_option('mytheme_favicon'); ?>
  <?php if($favicon){ ?>
	<link rel="icon" href="<?php echo get_option('mytheme_favicon'); ?>" type="image/x-icon" />
	<?php } else {?>
  <link rel="icon" href="<?php bloginfo( 'template_url' ); ?>/favicon.ico" type="image/x-icon" />
	<?php } ?>
  <link rel="icon" href="<?php echo get_option('mytheme_favicon'); ?>" type="image/x-icon" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo( 'name' ); ?>" href="<?php bloginfo( 'rss2_url' ); ?>" />
	<link rel="alternate" type="application/atom+xml" title="<?php bloginfo( 'name' ); ?>" href="<?php bloginfo( 'atom_url' ); ?>" />
	<!-- The HTML5 Shim is required for older browsers, mainly older versions IE -->
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
  <!--[if lt IE 7]>
    <div style=' clear: both; text-align:center; position: relative;'>
        <a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/images/upgrade.jpg" border="0"  alt="" /></a>
    </div>
<![endif]-->
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'template_url' ); ?>/css/prettyPhoto.css" />
  <link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'template_url' ); ?>/css/grid.css" />
	<?php
		/* We add some JavaScript to pages with the comment form
		 * to support sites with threaded comments (when in use).
		 */
		if ( is_singular() && get_option( 'thread_comments' ) )
			wp_enqueue_script( 'comment-reply' );
	
		/* Always have wp_head() just before the closing </head>
		 * tag of your theme, or you will break many plugins, which
		 * generally use this hook to add elements to <head> such
		 * as styles, scripts, and meta tags.
		 */
		wp_head();
	?>
  <script type="text/javascript">
  	// initialise plugins
		jQuery(function(){
			// main navigation init
			jQuery('ul.sf-menu').superfish({
				animation:   {opacity:'show', height:'show'}
			});
			
			// prettyphoto init
			jQuery(".video_cycle a[rel^='prettyPhoto']").prettyPhoto({
				animationSpeed:'slow',
				theme:'facebook',
				slideshow:false,
				autoplay_slideshow: false,
				show_title: true,
				overlay_gallery: false
			});
			
			jQuery('.widget.widget_wp_bannerize ul li a').prepend('<span class="arrow"></span>');
			
			jQuery('#sidebar .widget ul.video_cycle li a.video').prepend('<span class="play"></span>');
			
			// tooltip
			jQuery(".social-networks a").easyTooltip({
				xOffset:20,
				YOffset:25
			});
		})	
  </script>
  <!--[if lt IE 9]>
	  <script type="text/javascript">
			jQuery(function(){
				jQuery('#sidebar .widget ul li:nth-child(2n) a').css("background","url(<?php bloginfo('template_url'); ?>/images/arrow.gif) no-repeat 41px 50%");
			})	
	  </script>
  <![endif]-->
</head>

<body <?php body_class(); ?> onLoad="new ElementMaxHeight();">

<div id="main"><!-- this encompasses the entire Web site -->
	<header>
		<div class="container">
			<div class="logo">
      	<?php $logoimage = get_option('mytheme_logoimage'); ?>
      	<?php if($logoimage){?>
					<a href="<?php bloginfo('url'); ?>/"><img src="<?php echo get_option('mytheme_logoimage'); ?>" alt="<?php bloginfo('name'); ?>" title="<?php bloginfo('description'); ?>"></a>
				<?php } else { ?>
        	<?php if( is_front_page() || is_home() || is_404() ) { ?>
            <h1><a href="<?php bloginfo('url'); ?>/" title="<?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a></h1>
          <?php } else { ?>
            <h2><a href="<?php bloginfo('url'); ?>/" title="<?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a></h2>
          <?php } ?>
        <?php }?>
        <p class="description"><?php bloginfo('description'); ?></p>
      </div>
			<nav class="primary">
        <?php wp_nav_menu( array(
					'container'       => 'ul', 
					'menu_class'      => 'sf-menu', 
					'menu_id'         => 'topnav',
					'depth'           => 0,
					'theme_location' => 'header_menu' 
					)); 
				?>
			</nav><!--.primary-->
			<div id="widget-header">
				<?php if ( ! dynamic_sidebar( 'Header' ) ) : ?>
					<!-- Widgetized Header -->
				<?php endif ?>
			</div>
		</div><!--.container-->
	</header>
  <?php if( is_front_page() || is_home() ) { ?>
  		<div class="container">
			<div id="gallery">
			<div class="img-border"></div>
			<?php if ( ! dynamic_sidebar( 'Gallery' ) ) : ?>
			<!-- Widgetized Gallery -->
			<?php endif ?></div>
		</div>
  <?php } ?>
  <div class="container extra-cat"><?php if ( ! dynamic_sidebar( 'Categories' ) ) : ?>
			<!-- Widgetized Categories -->
			<?php endif ?></div>
	<div class="container">
	<div class="primary_content_wrap">
  	<div class="wrapper main-section">