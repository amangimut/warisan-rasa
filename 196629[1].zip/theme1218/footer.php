		</div><!--.wrapper-->
  	 </div><!--.primary_content_wrap-->		
  </div><!--.container-->
	<footer id="footer">
		<div class="container">
			<p><span class="fright"><!-- {%FOOTER_LINK} --></span><a href="<?php bloginfo('url'); ?>/" title="<?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a><br />
is proudly powered by <a href="http://wordpress.org">Wordpress</a> <a href="<?php bloginfo('rss2_url'); ?>" rel="nofollow">Entries (RSS)</a> and <a href="<?php bloginfo('comments_rss2_url'); ?>" rel="nofollow">Comments (RSS)</a></p>
		</div><!--.container-->
	</footer>
</div><!--#main-->
<?php wp_footer(); ?> <!-- this is used by many Wordpress features and for plugins to work proporly -->
<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>