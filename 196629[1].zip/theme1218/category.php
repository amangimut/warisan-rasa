<?php get_header(); ?>
<?php get_sidebar(); ?>
<div id="content" class="all-width">
	<div class="inside">
  	<h1><?php printf( __( 'Category Archives: %s' ), '<span>' . single_cat_title( '', false ) . '</span>' ); ?></h1>
		<?php echo category_description(); /* displays the category's description from the Wordpress admin */ ?>
    <ul class="cont-list">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <li>
        <h2 class="title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
      <div class="post-meta-top"><b><?php the_time('M j, Y'); ?> <?php the_time() ?></b> - Posted by <?php the_author_posts_link() ?></div>
	      <div class="wrapper"><a href="<?php the_permalink() ?>" class="featured-thumbnail"><?php the_post_thumbnail(); ?></a>
	      
	      <div class="post-content">
	         <div class="excerpt">
		    <?php the_excerpt(); ?>
		    </div>
             <span class="comm-counter"><?php comments_popup_link('comments <b>(0)</b>', 'comment <b>(1)</b>', 'comments <b>(%)</b>', 'comments-link', 'Comments are closed'); ?></span> <a href="<?php the_permalink() ?>" class="button">Read more</a>           </div></div>
      </li><!--.single-post-->
    <?php endwhile; else: ?>
      <li class="no-results">
        <p><strong>There has been an error.</strong></p>
        <p>We apologize for any inconvenience, please <a href="<?php bloginfo('url'); ?>/" title="<?php bloginfo('description'); ?>">return to the home page</a> or use the search form below.</p>
        <?php get_search_form(); /* outputs the default Wordpress search form */ ?>
      </li><!--noResults-->
    <?php endif; ?>
      </ul>
    <nav class="oldernewer">
      <div class="older">
        <p>
          <?php next_posts_link('&laquo; Older Entries') ?>
        </p>
      </div><!--.older-->
      <div class="newer">
        <p>
          <?php previous_posts_link('Newer Entries &raquo;') ?>
        </p>
      </div><!--.newer-->
    </nav><!--.oldernewer-->
  </div>
	
</div><!--#content-->
<?php get_footer(); ?>