<?php
function my_script() {
	if (!is_admin()) {
		wp_deregister_script('jquery');
		wp_register_script('jquery', get_bloginfo('template_url').'/js/jquery-1.4.4.min.js', false, '1.4.4');
		wp_enqueue_script('jquery');

		wp_enqueue_script('superfish', get_bloginfo('template_url').'/js/superfish.js', array('jquery'), '1.4.8');
		wp_enqueue_script('maxheight', get_bloginfo('template_url').'/js/maxheight.js', array('jquery'), '');
		wp_enqueue_script('prettyPhoto', get_bloginfo('template_url').'/js/jquery.prettyPhoto.js', array('jquery'), '3.0.1');
		wp_enqueue_script('easyTooltip', get_bloginfo('template_url').'/js/easyTooltip.js', array('jquery'), '1.0');
	
		wp_enqueue_script('yui', get_bloginfo('template_url').'/js/cufon-yui.js', array('jquery'), '');
		wp_enqueue_script('replace', get_bloginfo('template_url').'/js/cufon-replace.js', array('jquery'), '');
		wp_enqueue_script('Hattori_Hanzo', get_bloginfo('template_url').'/js/Lato_Black_900.font.js', array('jquery'), '');
		wp_enqueue_script('Lato_Light', get_bloginfo('template_url').'/js/Lato_Light_300.font.js', array('jquery'), '');
	}
}
add_action('init', 'my_script');
?>