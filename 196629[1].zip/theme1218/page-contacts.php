<?php
/*
 * Template Name: Contacts
 */

get_header(); ?>

<div id="full-width">
	<div id="content">
        <div class="inside">
	   	<h1><?php the_title(); ?></h1>
           <div class="wrapper">
              <div class="three_fifth">
                 <?php if ( ! dynamic_sidebar( 'Contact Form' ) ) : ?>
                 <!-- Widgetized Header -->
                 <?php endif ?>
                 <?php wp_reset_query(); ?>
              </div>
             <div class="two_fifth last_col">
                <?php if ( ! dynamic_sidebar( 'Address' ) ) : ?>
                <!-- Widgetized Header -->
                <?php endif ?>
                <?php wp_reset_query(); ?>
              </div>
           </div>
           <div class="line-hor"></div>
           <?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
           <div id="page-content">
              <?php the_content(); ?>
           </div><!--#pageContent -->
           <?php endwhile; ?>
        </div>
         <!--.indent-->
   </div><!--#content-->
</div>
<?php get_footer(); ?>
