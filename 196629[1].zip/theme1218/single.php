<?php get_header(); ?>
<div id="full-width"><div id="content">
	<div class="inside">
  	<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
      <div id="post-<?php the_ID(); ?>" <?php post_class('post'); ?>>
        <?php if ( get_post_type() == gallery ) { /* if a gallery */ ?>
  
          <article class="single-post">
            <h1><?php the_title(); ?></h1>
            <?php edit_post_link('<small>Edit this entry</small>','',''); ?>
            
            <?php echo '<div class="featured-thumbnail">'; the_post_thumbnail(); echo '</div>'; /* loades the post's featured thumbnail, requires Wordpress 3.0+ */ ?>
            
            <div id="post-content">
              <?php the_content(); ?>
              <?php wp_link_pages('before=<div class="pagination">&after=</div>'); ?>
            </div><!--#post-content-->
          </article>
  
        <?php } else { /* if not a gallery */ ?>
  
          <article class="single-post">
            <h1><?php the_title(); ?></h1>
            <div class="post-meta-top"><b><?php the_time('M j, Y'); ?> <?php the_time() ?></b> - Posted by <?php the_author_posts_link() ?></div>
            <?php edit_post_link('<small>Edit this entry</small>','',''); ?>
            <?php echo '<div class="featured-thumbnail">'; the_post_thumbnail(); echo '</div>'; /* loades the post's featured thumbnail, requires Wordpress 3.0+ */ ?>
            <div class="post-content">
              <?php the_content(); ?>
              <?php wp_link_pages('before=<div class="pagination">&after=</div>'); ?>
            </div><!--.post-content-->
            <div class="post-meta">
            	<?php the_tags('Tags: ', ', ', ' '); ?>
            </div>
          </article>
  
          <?php /* If a user fills out their bio info, it's included here */ ?>
          <div id="post-author">
            <h3>Written by <?php the_author_posts_link() ?></h3>
            <p class="gravatar"><?php if(function_exists('get_avatar')) { echo get_avatar( get_the_author_email(), '80' ); /* This avatar is the user's gravatar (http://gravatar.com) based on their administrative email address */  } ?></p>
            <div id="authorDescription">
              <?php the_author_meta('description') ?> 
              <div id="author-link">
                <p>View all posts by: <?php the_author_posts_link() ?></p>
              </div><!--#author-link-->
            </div><!--#author-description -->
          </div><!--#post-author-->
    
        </div><!-- #post-## -->
    		
        
        <nav class="oldernewer">
          <div class="older">
            <p>
              <?php previous_post_link('%link', '&laquo; Previous post') ?>
            </p>
          </div><!--.older-->
          <div class="newer">
            <p>
              <?php next_post_link('%link', 'Next Post &raquo;') ?>
            </p>
          </div><!--.newer-->
        </nav><!--.oldernewer-->
    
        <?php comments_template( '', true ); ?>
      <?php } /* end if-gallery */ ?>
  
    <?php endwhile; /* end loop */ ?>
  </div>
</div><!--#content--></div>
<?php get_footer(); ?>