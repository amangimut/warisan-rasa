<form method="get" id="searchform" action="<?php bloginfo('home'); ?>">

<span class="searching"><input type="text" value="search..." onfocus="if(this.value=='search...'){this.value=''}" onblur="if(this.value==''){this.value='search...'}" name="s" id="s" /><input class="submit" type="submit" value="" /></span>

</form>
