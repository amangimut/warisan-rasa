<?php get_header(); ?>
<div id="full-width"><div id="content">
	<div class="inside">
  	<?php
			if(isset($_GET['author_name'])) :
				$curauth = get_userdatabylogin($author_name);
				else :
				$curauth = get_userdata(intval($author));
			endif;
		?>
		<div class="author-info">
			<h1>About: <span><?php echo $curauth->display_name; ?></span></h1>
			<p class="avatar">
				<?php if(function_exists('get_avatar')) { echo get_avatar( $curauth->user_email, $size = '120' ); } /* Displays the Gravatar based on the author's email address. Visit Gravatar.com for info on Gravatars */ ?>
			</p>
			
			<?php if($curauth->description !="") { /* Displays the author's description from their Wordpress profile */ ?>
        <p><?php echo $curauth->description; ?></p>
      <?php } ?>
		</div><!--.author-->
	
		<div id="recent-author-posts">
      <h3>Recent Posts by <?php echo $curauth->display_name; ?></h3>
	 <ul class="cont-list">
      <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); /* Displays the most recent posts by that author. Note that this does not display custom content types */ ?>
        <?php static $count = 0;
          if ($count == "5") // Number of posts to display
                  { break; }
          else { ?>
		<li>
            <h2 class="title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
      <div class="post-meta-top"><b><?php the_time('M j, Y'); ?> <?php the_time() ?></b> - Posted by <?php the_author_posts_link() ?></div>
	      <div class="wrapper"><a href="<?php the_permalink() ?>" class="featured-thumbnail"><?php the_post_thumbnail(); ?></a>
	      
	      <div class="post-content">
	         <div class="excerpt">
		    <?php the_excerpt(); ?>
		    </div>
             <span class="comm-counter"><?php comments_popup_link('comments <b>(0)</b>', 'comment <b>(1)</b>', 'comments <b>(%)</b>', 'comments-link', 'Comments are closed'); ?></span> <a href="<?php the_permalink() ?>" class="button">Read more</a>           </div></div>
		   </li>
        <?php $count++; } ?>
      <?php endwhile; else: ?>
          <li>
            No posts by <?php echo $curauth->display_name; ?> yet.
          </li>
      <?php endif; ?>
	 </ul>  
    </div><!--#recentPosts-->
	
		<div id="recent-author-comments">
      <h3>Recent Comments by <?php echo $curauth->display_name; ?></h3>
        <?php
          $number=5; // number of recent comments to display
          $comments = $wpdb->get_results("SELECT * FROM $wpdb->comments WHERE comment_approved = '1' and comment_author_email='$curauth->user_email' ORDER BY comment_date_gmt DESC LIMIT $number");
        ?>
        <ul>
          <?php
            if ( $comments ) : foreach ( (array) $comments as $comment) :
            echo  '<li class="recentcomments">' . sprintf(__('%1$s on %2$s'), get_comment_date(), '<a href="'. get_comment_link($comment->comment_ID) . '">' . get_the_title($comment->comment_post_ID) . '</a>') . '</li>';
          endforeach; else: ?>
                    <p>
                      No comments by <?php echo $curauth->display_name; ?> yet.
                    </p>
          <?php endif; ?>
              </ul>
    </div><!--#recentAuthorComments-->
    
  </div>
</div><!--#content--></div>
<?php get_footer(); ?>