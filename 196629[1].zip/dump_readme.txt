To make your WordPress look like our live demo please, follow the instructions bellow.

1. Please, copy the folder with the theme to /wp-content/themes/ folder. 

2. Then, copy and unzip files from the folder "plugins"  to the /wp-content/plugins/ folder.

3. Copy "uploads" and "gallery" folders to /wp-content folder.

4. "Open the themeXXXX.sql file that is located in sources folder with any text editor and replace all instances of "your_website_url_here" to your website URL in the entire document using Find and Replace tool (usually Ctrl+H hot key). 
E.g.: http://www.mywebsite.com
Please, make sure that you do not have the forward slash "/" sign in the end of the address. 
Save and close the file." 

5.Next, you can import the dump file.

ATTENTION! By importing the dump file you will lose all of website data.

Note! If the menu does not appear as livedemo, then go to Appereance > Menus and select the dropdown "HeaderMenu"
